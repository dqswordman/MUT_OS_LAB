#include <pigpio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>

#pragma pack(1)

#define FRONT   0
#define BACK    1
#define LEFT    2
#define RIGHT   3

#define PORT 8888

#define servoForward    5
#define servoDirection  6
#define servoEnable     4
#define servoA1         12
#define servoA2         13
#define servoB1         16
#define servoB2         17

uint8_t running=true;
typedef struct{
    uint8_t distance[4];
    int8_t  speed;
    int8_t  direction;
    uint8_t autoMode;
    uint8_t dummy;
    uint16_t CRC;
}carStatusType;
carStatusType carStatus={{0},0,0,0,0,0};

typedef struct{
    int8_t speed;
    int8_t direction;
    uint8_t autoMode;
    uint8_t dummy;
    uint16_t CRC;
}carControlType;
carControlType carControl={0,0,0,0,0};

int sensorTrig[4]={20,22,24,26};
int sensorEcho[4]={21,23,25,27};

#define NUMTHREAD 9

void gpioStop(int sig);
void initGPIO();

void *ultraSonic(void *param);
void *networkControl(void *param);
void *PWMforward(void *param);
void *PWMdirection(void *param);
void *command(void *param);
void *autoControl(void *param);

int main(){
    int i;
    int threadsParam[NUMTHREAD];
    void *(*threads[NUMTHREAD])(void *)={ultraSonic,ultraSonic,ultraSonic,ultraSonic,
                                         networkControl,PWMforward,PWMdirection,command,autoControl};
    pthread_t tid[NUMTHREAD];
    pthread_attr_t attr[NUMTHREAD];

    initGPIO();
    signal(SIGINT,gpioStop);

    for(i=0;i<NUMTHREAD;i++){
        threadsParam[i]=i;
        pthread_attr_init(&attr[i]);
        pthread_create(&tid[i],&attr[i],threads[i],(void *)&threadsParam[i]);
    }

    while(running){
        printf("f[%3d] b[%3d] l[%3d] r[%3d]||SPEED=[%4d](%4d) DIR=[%4d](%4d) AUTO=",
                carStatus.distance[FRONT],carStatus.distance[BACK],
                carStatus.distance[LEFT],carStatus.distance[RIGHT],
                carStatus.speed,carControl.speed,carStatus.direction,carControl.direction);
        if(carStatus.autoMode<1)
            printf("OFF\r");
        else
            printf("ON \r");
        fflush(stdout);
        usleep(100000);
    }

    printf("Wait for threads to stop.\n");
    fflush(stdout);
    for(i=0;i<NUMTHREAD;i++)
        pthread_join(tid[i],NULL);
    gpioTerminate();
    return 0;
}

void *ultraSonic(void *param){
    int clock1,clock2,timeout,dclock;
    int id = *(int *)param;

    while(running){
        gpioWrite(sensorTrig[id],1);
        usleep(10);
        gpioWrite(sensorTrig[id],0);
        for(timeout=0;(timeout<10000)&&(gpioRead(sensorEcho[id])==0);timeout++) usleep(100);
        clock1=clock();
        for(timeout=0;(timeout<10000)&&(gpioRead(sensorEcho[id])==1);timeout++) usleep(100);
        clock2=clock();
        if(timeout<10000){
            if((dclock=(clock2-clock1)/100)<=10)
                carStatus.distance[id]=dclock;
            else
                carStatus.distance[id]=10;
        }
        usleep(100000);
    }
    pthread_exit(NULL);
}

void *networkControl(void *param){
    struct sockaddr_in s_me,s_other;
    int s,rLen,s_len=sizeof(s_other);

    if((s=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP))==-1){
        printf("Cannot start UDP server\n");
        running=false;
        pthread_exit(NULL);
    }
    memset((char *)&s_me,0,sizeof(s_me));
    s_me.sin_family = AF_INET;
    s_me.sin_port = htons(PORT);
    s_me.sin_addr.s_addr = htonl(INADDR_ANY);
    if(bind(s,(struct sockaddr *)&s_me,sizeof(s_me))==-1){
        printf("Cannot bind UDP port\n");
        close(s);
        running=false;
        pthread_exit(NULL);
    }

//set UDP timeout to 1 second
    struct timeval tv;
    tv.tv_sec=1;
    tv.tv_usec=0;
    if(setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv))<0){
        printf("Cannot set UDP timeout\n");
        close(s);
        running=false;
        pthread_exit(NULL);
    }

    while(running){
//        memset(&carControl,0,sizeof(carControlType));
        if((rLen = recvfrom(s,&carControl,sizeof(carControlType),
                        0,(struct sockaddr *)&s_other,(socklen_t *)&s_len))<0){
            printf("Timeout\n");
            continue;
//            running=false;
        }
//            carStatus.speed = carControl.speed;
//            carStatus.direction = carControl.direction;

        if(sendto(s,&carStatus,sizeof(carStatusType),0,(struct sockaddr *)&s_other,s_len)==-1){
            printf("Error sending data\n");
            running=false;
        }
    }
    close(s);
    pthread_exit(NULL);
}

void *PWMforward(void *param){
    int pON,pOFF;
/*
    while(running){
        if(carStatus.speed!=0)
            gpioWrite(servoForward,1);
        else
            gpioWrite(servoForward,0);
    usleep(20000);

    }
*/
    while(running){
        if(carStatus.speed<0){
            if(carStatus.speed<100)
                pON=20000;
            else
                pON=((int)(-carStatus.speed))*200;
        }else{
            if(carStatus.speed>100)
                pON=20000;
            else
                pON=(int)carStatus.speed*200;
        }
        pOFF=20000-pON;
        gpioWrite(servoForward,1);
        usleep(pON);
        gpioWrite(servoForward,0);
        usleep(pOFF);
    }
    gpioWrite(servoForward,0);
    pthread_exit(NULL);
}
void *PWMdirection(void *param){
// Temporary work for DC-motor with left-right
    while(running){
    if(carStatus.direction!=0)
        gpioWrite(servoDirection,1);
    else
        gpioWrite(servoDirection,0);
    usleep(20000);
    }
    gpioWrite(servoDirection,0);
    pthread_exit(NULL);
}

void *command(void *param){
    gpioWrite(servoEnable,1);
    while(running){
        if(carStatus.direction<0){
            gpioWrite(servoB1,1);
            gpioWrite(servoB2,0);
        }
        else if(carStatus.direction>0){
            gpioWrite(servoB1,0);
            gpioWrite(servoB2,1);
        }
        else{
            gpioWrite(servoB1,0);
            gpioWrite(servoB2,0);
        }

        if(carStatus.speed>0){
            gpioWrite(servoA1,1);
            gpioWrite(servoA2,0);
        }else if(carStatus.speed<0){
            gpioWrite(servoA1,0);
            gpioWrite(servoA2,1);
        }else{
            gpioWrite(servoA1,0);
            gpioWrite(servoA2,0);
        }
        usleep(100000);
    }
    gpioWrite(servoEnable,0);
    pthread_exit(NULL);
}

void *autoControl(void *param){
    while(running){
        carStatus.autoMode = carControl.autoMode;

        if(carControl.autoMode<1){
            carStatus.speed = carControl.speed;
            carStatus.direction = carControl.direction;
        }else{
        // Check for front-rear collision
            if(((carStatus.distance[FRONT]<3)&&(carControl.speed>0))||
               ((carStatus.distance[BACK]<3)&&(carControl.speed<0)))
                carStatus.speed=0;
            else
                carStatus.speed = carControl.speed;
        // Check for left-right collision
            if(carStatus.distance[LEFT]<3){
                carStatus.direction = 100;
                }
            else
            if(carStatus.distance[RIGHT]<3)
                carStatus.direction = -100;
            else
                carStatus.direction = carControl.direction;

        }
        usleep(10000);
    }
    pthread_exit(NULL);
}

void initGPIO(){
    int i;
    if(gpioInitialise() <0) exit(-1);

    for(i=0;i<4;i++){
        gpioSetMode(sensorTrig[i],PI_OUTPUT);
        gpioSetMode(sensorEcho[i],PI_INPUT);
        gpioSetPullUpDown(sensorEcho[i],PI_PUD_OFF);
    }
    gpioSetMode(servoDirection,PI_OUTPUT);
    gpioSetMode(servoForward,PI_OUTPUT);
    gpioSetMode(servoEnable,PI_OUTPUT);
    gpioSetMode(servoA1,PI_OUTPUT);
    gpioSetMode(servoA2,PI_OUTPUT);
    gpioSetMode(servoB1,PI_OUTPUT);
    gpioSetMode(servoB2,PI_OUTPUT);
}

void gpioStop(int sig){
    printf("CTRL-C pressed.\n");
    running = false;
}
