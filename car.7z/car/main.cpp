#include <pigpio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>

#pragma pack(1)

#define FRONT   0
#define BACK    1
#define LEFT    2
#define RIGHT   3

#define PORT 8888

#define servoA          5		      // Unused because DRV8833 send pulse directly to A1/A2/B1/B2
#define servoB          6		// Unused, see above
#define servoC          5		// Servo 90g LEFT
#define servoD          6		// Servo 90g RIGHT
#define servoA1         13		// Motor LEFT AIN1
#define servoA2         12		// Motor LEFT AIN2
#define servoB1         17		// Motor RIGHT BIN1
#define servoB2         16		// Motor RIGHT BIN2

#define PWMDELAY        10000
#define PWMDELAY2       100     // 1/100 of the PWMDELAY

#define USDETECT        6       // Ultrasonic sensitivity
#define USMIN           3       // Ultrasonic minimum distance allowance

volatile int pwmA=0,pwmB=0;
volatile int pwmC=50,pwmD=50;

uint8_t running=true;
typedef struct{
    uint8_t distance[4];
    int8_t  speed;
    int8_t  direction;
    uint8_t autoMode;
    uint8_t sensorSearch;
    uint16_t CRC;
}carStatusType;
carStatusType carStatus={{0},0,0,0,0,0};

typedef struct{
    int8_t speed;
    int8_t direction;
    int8_t calibrate;
    uint8_t autoMode;
    uint8_t sensorSearch;
    uint8_t dummy;
    uint16_t CRC;
}carControlType;
carControlType carControl={0,0,0,0,0};

//int sensorTrig[4]={20,22,24,26};
//int sensorEcho[4]={21,23,25,27};
int sensorTrig[4]={20,22,24,26};
int sensorEcho[4]={21,23,25,27};

#define NUMTHREAD 11

void gpioStop(int sig);
void initGPIO();

void *ultraSonic(void *param);
void *networkControl(void *param);
void *PWMl(void *param);
void *PWMr(void *param);
void *command(void *param);
void *autoControl(void *param);
void *PWMc(void *param);
void *PWMd(void *param);

int main(){
    int i;
    int threadsParam[NUMTHREAD];
    void *(*threads[NUMTHREAD])(void *)={ultraSonic,ultraSonic,ultraSonic,ultraSonic,
                                         networkControl,PWMl,PWMr,command,autoControl,PWMc,PWMd};
    pthread_t tid[NUMTHREAD];
    pthread_attr_t attr[NUMTHREAD];

    initGPIO();
    signal(SIGINT,gpioStop);

    for(i=0;i<NUMTHREAD;i++){
        threadsParam[i]=i;
        pthread_attr_init(&attr[i]);
        pthread_create(&tid[i],&attr[i],threads[i],(void *)&threadsParam[i]);
    }

    while(running){
        printf("D[%2d|%2d]F-B[%2d|%2d]LR[%2d|%2d]||SP=[%4d](%4d)DR=[%4d](%4d|%3d)AT=",
                pwmC,pwmD,carStatus.distance[FRONT],carStatus.distance[BACK],
                carStatus.distance[LEFT],carStatus.distance[RIGHT],
                carStatus.speed,carControl.speed,carStatus.direction,carControl.direction,carControl.calibrate);
        switch(carStatus.autoMode){
            case 0: printf("OFF  ");break;
            case 1: printf("ON   ");break;
            case 2: printf("SMRT ");break;
            default:printf("DOG  ");
        }
        if(carControl.sensorSearch==1)
            printf("SR=ON \r");
            else printf("SR=OFF\r");
        fflush(stdout);
        usleep(100000);
    }

    printf("Wait for threads to stop.\n");
    fflush(stdout);
    for(i=0;i<NUMTHREAD;i++)
        pthread_join(tid[i],NULL);
    gpioTerminate();
    return 0;
}

void *ultraSonic(void *param){
    int clock1,clock2,timeout,dclock;
    int id = *(int *)param;
    int Scount;

    while(running){
        if(carControl.sensorSearch==1){
        // Sensor direction for Left/Right sensor
        if(id==LEFT){
        if(Scount>=20) Scount=0;
        if(Scount<10) pwmC = (Scount*80)/10+10;
        else pwmC = ((20-Scount)*80)/10+10;
        Scount++;
        }
        if(id==RIGHT){
        if(Scount>=20) Scount=0;
        if(Scount<10) pwmD = (Scount*80)/10+10;
        else pwmD = ((20-Scount)*80)/10+10;
        Scount++;
        }
        }
        else{
        if(id==LEFT)
            pwmC = 10;
        if(id==RIGHT)
            pwmD = 90;
        }

        // Pulse making
        gpioWrite(sensorTrig[id],1);
        usleep(10);
        gpioWrite(sensorTrig[id],0);
        for(timeout=0;(timeout<10000)&&(gpioRead(sensorEcho[id])==0);timeout++) usleep(100);
        clock1=clock();
        for(timeout=0;(timeout<10000)&&(gpioRead(sensorEcho[id])==1);timeout++) usleep(100);
        clock2=clock();
        if(timeout<10000){
            if((dclock=(clock2-clock1)/100)<=10)
                carStatus.distance[id]=dclock;
            else
                carStatus.distance[id]=10;
        }
        usleep(100000);
    }
    pthread_exit(NULL);
}

void *networkControl(void *param){
    struct sockaddr_in s_me,s_other;
    int s,rLen,s_len=sizeof(s_other);

    if((s=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP))==-1){
        printf("Cannot start UDP server\n");
        running=false;
        pthread_exit(NULL);
    }
    memset((char *)&s_me,0,sizeof(s_me));
    s_me.sin_family = AF_INET;
    s_me.sin_port = htons(PORT);
    s_me.sin_addr.s_addr = htonl(INADDR_ANY);
    if(bind(s,(struct sockaddr *)&s_me,sizeof(s_me))==-1){
        printf("Cannot bind UDP port\n");
        close(s);
        running=false;
        pthread_exit(NULL);
    }

//set UDP timeout to 1 second
    struct timeval tv;
    tv.tv_sec=1;
    tv.tv_usec=0;
    if(setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv))<0){
        printf("Cannot set UDP timeout\n");
        close(s);
        running=false;
        pthread_exit(NULL);
    }

    while(running){
//        memset(&carControl,0,sizeof(carControlType));
        if((rLen = recvfrom(s,&carControl,sizeof(carControlType),
                        0,(struct sockaddr *)&s_other,(socklen_t *)&s_len))<0){
            printf("Timeout\n");
            continue;
//            running=false;
        }
//            carStatus.speed = carControl.speed;
//            carStatus.direction = carControl.direction;

        if(sendto(s,&carStatus,sizeof(carStatusType),0,(struct sockaddr *)&s_other,s_len)==-1){
            printf("Error sending data\n");
            running=false;
        }
    }
    close(s);
    pthread_exit(NULL);
}

void *PWMl(void *param){
    int pON,pOFF,servo;

    while(running){
        if((pwmA<-100)||(pwmA>100)) pON = PWMDELAY;
        else if(pwmA<0) pON=((int)(-pwmA))*PWMDELAY2;
        else pON=(int)pwmA*PWMDELAY2;

		if(pwmA<0) servo = servoA1;
		else servo = servoA2;

        pOFF=PWMDELAY-pON;
        gpioWrite(servo,1);
        usleep(pON);
        gpioWrite(servo,0);
        usleep(pOFF);
    }
    gpioWrite(servoA,0);
    pthread_exit(NULL);
}

void *PWMr(void *param){
    int pON,pOFF,servo;

    while(running){
        if((pwmB<-100)||(pwmB>100)) pON = PWMDELAY;
        else if(pwmB<0) pON=((int)(-pwmB))*PWMDELAY2;
        else pON=(int)pwmB*PWMDELAY2;

		if(pwmB<0) servo = servoB1;
		else servo = servoB2;

        pOFF=PWMDELAY-pON;
        gpioWrite(servo,1);
        usleep(pON);
        gpioWrite(servo,0);
        usleep(pOFF);
    }
    gpioWrite(servoB,0);
    pthread_exit(NULL);

}

void *PWMc(void *param){
    int pON,pOFF;
    int oldPWM=50;
    int count=0;
    while(running){
        if(oldPWM==pwmC){
          count++;
          if(count>20)count=0;
          else{ usleep(20000); continue;}
        }
        oldPWM=pwmC;
        pON = pwmC*10+1000;
        pOFF = (100-pwmC)*10+18000;
        gpioWrite(servoC,1);
        usleep(pON);
        gpioWrite(servoC,0);
        usleep(pOFF);
    }
    pthread_exit(NULL);
}

void *PWMd(void *param){
    int pON,pOFF;
    int oldPWM=50;
    int count=0;
    while(running){
        if(oldPWM==pwmD){
            count++;
            if(count>20) count=0;
            else { usleep(20000); continue;}
        }
        oldPWM=pwmD;
        pON = pwmD*10+1000;
        pOFF = (100-pwmD)*10+18000;
        gpioWrite(servoD,1);
        usleep(pON);
        gpioWrite(servoD,0);
        usleep(pOFF);
    }
    pthread_exit(NULL);
}

void *command(void *param){
//    gpioWrite(servoEnable,1);
    while(running){
        if(carControl.calibrate>=0){
        pwmA=((int)carStatus.speed*(100-(int)carControl.calibrate)/100)-(int)(carStatus.direction);
        pwmB=(int)carStatus.speed+(int)(carStatus.direction);
        }else
        {
        pwmA=(int)carStatus.speed-(int)(carStatus.direction);
        pwmB=((int)carStatus.speed*(100+(int)carControl.calibrate)/100)+(int)(carStatus.direction);
        }/*
        if(pwmA<0){
            gpioWrite(servoA1,1);
            gpioWrite(servoA2,0);
        }else{
            gpioWrite(servoA1,0);
            gpioWrite(servoA2,1);
        }

        if(pwmB<0){
            gpioWrite(servoB1,1);
            gpioWrite(servoB2,0);
        }else{
            gpioWrite(servoB1,0);
            gpioWrite(servoB2,1);
        }*/
        usleep(50000);
    }
//    gpioWrite(servoEnable,0);
    pthread_exit(NULL);
}

void *autoControl(void *param){
    while(running){
        carStatus.autoMode = carControl.autoMode;

        switch(carControl.autoMode){
            case 0:  // Manual only mode
                carStatus.speed = carControl.speed;
                carStatus.direction = carControl.direction;
                break;
            case 1:   // AUTO collision avoidance mode
        // Check for front-rear collision
            if((carStatus.distance[FRONT]<USDETECT)&&(carControl.speed>=0))
//                carStatus.speed=-50;
                carStatus.speed = (int)((float)carControl.speed *
                            (float)(carStatus.distance[FRONT]-USMIN)/(float)(USDETECT-USMIN));
            else
            if((carStatus.distance[BACK]<USDETECT)&&(carControl.speed<=0))
//                carStatus.speed=50;
                carStatus.speed = (int)((float)carControl.speed *
                            (float)(carStatus.distance[BACK]-USMIN)/(float)(USDETECT-USMIN));
            else
                carStatus.speed = carControl.speed;
        // Check for left-right collision
            if((carStatus.distance[LEFT]<USDETECT)&&(carStatus.distance[RIGHT]<USDETECT)){
            //Narrow path way
                carStatus.direction = (int)((float)(carStatus.distance[RIGHT]-carStatus.distance[LEFT])/50.0);
            }
            if(carStatus.distance[LEFT]<USDETECT){
                carStatus.direction = carControl.direction-(int)(50.0*
                      (float)(carStatus.distance[LEFT]-USDETECT)/(float)(USDETECT));
                }
            else
            if(carStatus.distance[RIGHT]<USDETECT)
                carStatus.direction = carControl.direction+(int)(50.0*
                      (float)(carStatus.distance[RIGHT]-USDETECT)/(float)(USDETECT));
//                carStatus.direction = -100;
            else
                carStatus.direction = carControl.direction;
            break;
        case 2: // Auto avoidance and move to other spots mode
            if(carControl.speed>=0){
            // Forward collision checking

          // backtraking from corner
            if((carStatus.distance[FRONT]<USDETECT)&&
                (carStatus.distance[LEFT]<USDETECT)&&
                (carStatus.distance[RIGHT]<USDETECT)){

                    carStatus.speed=-50;
                    carStatus.direction=-100;
                }
             else
             // Turn right
             if((carStatus.distance[FRONT]<USDETECT)&&
                (carStatus.distance[LEFT]<USDETECT)&&
                (carStatus.distance[RIGHT]>=USDETECT)){

                    carStatus.speed=-100;
                    carStatus.direction=100;
                }
                else
               // Turn left
             if((carStatus.distance[FRONT]<USDETECT)&&
                (carStatus.distance[LEFT]>=USDETECT)&&
                (carStatus.distance[RIGHT]<USDETECT)){

                    carStatus.speed=-50;
                    carStatus.direction=-100;
                }else
                // Front only
             if(carStatus.distance[FRONT]<USDETECT){

                    carStatus.speed=-50;
                    carStatus.direction=-100;
                }
            else
            // turn right if left check
             if(carStatus.distance[LEFT]<USDETECT){

                    carStatus.speed=carControl.speed;
                    carStatus.direction=100;
                }
                else
               // Turn left
             if(carStatus.distance[RIGHT]<USDETECT){
                    carStatus.speed=carControl.speed;
                    carStatus.direction=-100;
                }
                else{
                carStatus.speed=carControl.speed;
                carStatus.direction=carControl.direction;
                }
            }else{
            //Backing run
            if(carStatus.distance[BACK]<USDETECT){
                carStatus.speed=50;
                carStatus.direction=-100;
                }
            else
            if(carStatus.distance[LEFT]<USDETECT){
                carStatus.speed=0;
                carStatus.direction = 100;
                }
            else
            if(carStatus.distance[RIGHT]<USDETECT){
                carStatus.speed=0;
                carStatus.direction = -100;
                }
            else{
                carStatus.speed=carControl.speed;
                carStatus.direction = carControl.direction;
                }
            }  break;
            default:  // Auto following with avoideance mode
            if(carControl.speed>=0){
            // Forward collision checking
            int followDirection = 0;
            int minDirection = 10;
            int temp;

            // Check which sensor is the strongest signal
            if((temp=carStatus.distance[RIGHT])< minDirection){
                followDirection = 1;
                minDirection = temp;
            }

            if((temp=carStatus.distance[LEFT])< minDirection){
                followDirection = -1;
                minDirection = temp;
            }
            if((temp=carStatus.distance[FRONT])< minDirection){
                followDirection = 0;
                minDirection = temp;
            }

            if((temp=carStatus.distance[BACK])< minDirection){
                followDirection = -2;
                minDirection = temp;
            }

            if((minDirection <10)&&(minDirection > 1)){
            // Following mode.
                if(followDirection == 0){
                    carStatus.speed = 50;
                    carStatus.direction = 0;
                    printf("FORWARD\r");fflush(stdout);
                    }else
                    if(followDirection == -1 ){
                        carStatus.speed = 50;
                        carStatus.direction = -100;
                        printf("LEFT   \r");fflush(stdout);
                    }else
                    if(followDirection == 1 ){
                        carStatus.speed = 50;
                        carStatus.direction = 100;
                        printf("RIGHT  \r");fflush(stdout);
                    }else{
                        carStatus.speed = 0;
                        carStatus.direction = -100;
                        printf("AROUND \r");fflush(stdout);
                    }
            }
            else{
          // backtraking from corner
            if(carStatus.distance[FRONT]<USDETECT){
                    carStatus.speed=-50;
                    carStatus.direction=0;
                }
             else
             // Turn right
             if(carStatus.distance[LEFT]<USDETECT){

                    carStatus.speed=-50;
                    carStatus.direction=-100;
                }
                else
               // Turn left
             if(carStatus.distance[RIGHT]<USDETECT){

                    carStatus.speed=-50;
                    carStatus.direction=100;
                }
            else
            // turn right if left check
             if(carStatus.distance[LEFT]<USDETECT){

                    carStatus.speed=carControl.speed;
                    carStatus.direction=100;
                }
                else
               // Turn left
             if(carStatus.distance[RIGHT]<USDETECT){
                    carStatus.speed=carControl.speed;
                    carStatus.direction=-100;
                }
                else{
                carStatus.speed=carControl.speed;
                carStatus.direction=carControl.direction;
                }}
            }else{
            //Backing run
            if(carStatus.distance[BACK]<USDETECT){
                carStatus.speed=50;
                carStatus.direction=-100;
                }
            else
            if(carStatus.distance[LEFT]<USDETECT){
                carStatus.speed=0;
                carStatus.direction = 100;
                }
            else
            if(carStatus.distance[RIGHT]<USDETECT){
                carStatus.speed=0;
                carStatus.direction = -100;
                }
            else{
                carStatus.speed=carControl.speed;
                carStatus.direction = carControl.direction;
                }
            }
        }
        usleep(10000);
    }
    pthread_exit(NULL);
}

void initGPIO(){
    int i;
    if(gpioInitialise() <0) exit(-1);

    for(i=0;i<4;i++){
        gpioSetMode(sensorTrig[i],PI_OUTPUT);
        gpioSetMode(sensorEcho[i],PI_INPUT);
        gpioSetPullUpDown(sensorEcho[i],PI_PUD_OFF);
    }
//    gpioSetMode(servoA,PI_OUTPUT);
//    gpioSetMode(servoB,PI_OUTPUT);
    gpioSetMode(servoC,PI_OUTPUT);
    gpioSetMode(servoD,PI_OUTPUT);
    gpioSetMode(servoA1,PI_OUTPUT);
    gpioSetMode(servoA2,PI_OUTPUT);
    gpioSetMode(servoB1,PI_OUTPUT);
    gpioSetMode(servoB2,PI_OUTPUT);
    gpioWrite(servoC,0);
    gpioWrite(servoD,0);
}

void gpioStop(int sig){
    printf("CTRL-C pressed.\n");
    running = false;
}
